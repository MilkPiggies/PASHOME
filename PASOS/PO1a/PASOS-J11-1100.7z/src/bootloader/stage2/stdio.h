#pragma once

void putc(char c);
void puts(const char* str);
